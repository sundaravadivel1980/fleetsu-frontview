import { RsStandardPayload } from './rule-rs-payload.model';

export class Currency {
    public code: string;
    public countryCode: string;
    public decimalPlaces: number;
    public name: string;
}

export class CurrencyRs {
    public currency: Currency[];
    public rsStandardPayload: RsStandardPayload;
}
