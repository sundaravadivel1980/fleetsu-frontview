import { RsStandardPayload } from './rule-rs-payload.model';

export class CityAirport {
    public airport: string;
    public city: string;
    public code: string;
    public country: string;
    public timeZone: string;
}

export class CityAirportRs {
    public cityAirport: CityAirport[];
    public rsStandardPayload: RsStandardPayload;
}
