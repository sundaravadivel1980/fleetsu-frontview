import { RsStandardPayload } from './rule-rs-payload.model';

export class Country {
    public addlTxt: string;
    public code: string;
    public name: string;
}

export class CountryRs {
    public country: Country[];
    public rsStandardPayload: RsStandardPayload;
}
