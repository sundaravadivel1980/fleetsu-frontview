import { RsStandardPayload } from './rule-rs-payload.model';

export class Airline {
    public carrier: string;
    public name: string;
    public typeOfOperations: string;
    public threeLetterCode: string;
    public airlineInd: string;
}

export class AirlineRs {
    public airline: Airline[];
    public rsStandardPayload: RsStandardPayload;
}
