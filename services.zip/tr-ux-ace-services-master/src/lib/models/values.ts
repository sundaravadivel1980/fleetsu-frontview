
    export class Values {
        public code: string;
        public detail: string;
        public data: string[];
    }
