
    import { RsStandardPayload } from './rule-rs-payload.model';
    import { Values } from './values';

    export class Groupings {
        public code: string;
        public description: string;
        public values: Values[];
    }

    export class TypeOfGroupings {
        public name: string;
        public description: string;
        public groupings: Groupings[];
    }

    export class GroupingRs {
        public typeOfGroupings: TypeOfGroupings[];
        public rsStandardPayload: RsStandardPayload;
    }
