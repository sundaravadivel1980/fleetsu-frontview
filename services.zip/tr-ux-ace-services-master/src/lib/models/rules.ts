import { RqStandardPayload } from './rule-rq-payload.model';
import { RsStandardPayload } from './rule-rs-payload.model';

export class RuleRq {
  public rqStandardPayload: RqStandardPayload;
  public rule: Rule[];
}

export class Rule {
  public id: number;
  public type: string;
  public name: string;
  public quickRule: string;
  public status: string;
  public time: string;
  public userId: string;
  public version: number;
  public action: Action[];
  public keyword: string;
}

export class Action {
  public transaction: string;
  public availabilityAdjustmentAction: AvailabilityAdjustmentAction;
  public bidPriceAdjustmentAction: BidPriceAdjustmentAction;
  public classClosureAction: ClassClosureAction;
  public classSuppressionAction: ClassSuppressionAction;
  public marketFareAdjustmentAction: MarketFareAdjustmentAction;
}

export class ActionType {
  public arrivalTimeCondition: DateTimeCondition[];
  public carrierCondition: CarrierCondition[];
  public classAvailabilityCondition: ClassAvailabilityCondition[];
  public classBookingCondition: ClassBookingCondition[];
  public classCondition: ClassCondition[];
  public connectionPointCondition: ConnectionPointCondition[];
  public connectionTimeCondition: ConnectionTimeCondition[];
  public departureDateCondition: DateTimeCondition[];
  public departureTimeCondition: DateTimeCondition[];
  public effectiveDateTimeCondition: DateTimeCondition[];
  public equipmentCondition: EquipmentCondition[];
  public flightCondition: FlightCondition[];
  public frequentFlyerCondition: FrequentFlyerCondition[];
  public loadFactorCondition: LoadFactorCondition[];
  public marketCondition: MarketCondition[];
  public pointOfCommencementCondition: PointOfCommencementCondition[];
  public pointOfSaleCondition: PointOfSaleCondition[];
  public routingCondition: RoutingCondition[];
  public sellingDateTimeCondition: DateTimeCondition[];
  public timeOutsideDepartureCondition: TimeDepartureCondition[];
  public timeToDepartureCondition: TimeDepartureCondition[];
}

export class AvailabilityAdjustmentAction extends ActionType {
  public actionInput: AvailabilityActionInput[];
}

export class BidPriceAdjustmentAction extends ActionType {
  public actionInput: BidPriceActionInput;
  public adjustLeg: boolean;
}

export class ClassClosureAction extends ActionType {
  public actionInput: ClassClosureActionInput;
}

export class ClassSuppressionAction extends ActionType {}

export class MarketFareAdjustmentAction extends ActionType {
  public actionInput: MarketFareActionInput;
  public adjustLeg: boolean;
}

export class AvailabilityActionInput {
  public changeAmount: number;
  public changePercent: number;
  public maximum: number;
  public maximumIncrease: number;
  public minimum: number;
  public overrideSegmentLimit: boolean;
  public useAuAvailability: boolean;
}

export class BidPriceActionInput {
  public bidPrice: number;
  public changeAmount: number;
  public changePercent: number;
  public maximum: number;
  public minimum: number;
  public categories: Categories;
  public seats: BidPriceSeat[];
  public cabin: any;
}

export class Categories {
  public all: boolean;
  public connection: boolean;
  public local: boolean;
  public reward: boolean;
  public opaque: boolean;
}

export class BidPriceSeat {
  public endSeat: string;
  public startSeat: string;
  public seatsRestriction: string;
}

export class ClassClosureActionInput {
  public unblock: boolean;
  public waitlistClose: boolean;
}

export class ClassSuppressionActionInput {
  public display: boolean;
}

export class MarketFareActionInput {
  public amount: number;
  public changeAmount: number;
  public changePercent: number;
  public maximum: number;
  public minimum: number;
}

export class DateTimeCondition {
  public comparator: string;
  public dateOrRange: DateOrRange;
  public dayOfWeek: any[];
}

export class DateOrRange {
  public endDateTime: string;
  public startDateTime: string;
}

export class CarrierCondition {
  public comparator: string;
  public marketing: any;
  public operating: any;
}

export class ClassBookingCondition {
  public comparator: string;
  public cabin: any;
  public classOfService: any;
  public seats: Seat;
}

export class ClassAvailabilityCondition {
  public comparator: string;
  public cabin: any;
  public classOfService: any;
  public seats: Seat;
}

export class Seat {
  public seatComparator: string;
  public count: number;
  public segment: ClassSegment[];
}

export class ClassSegment {
  public origin: any;
  public destination: any;
}

export class ClassCondition {
  public comparator: string;
  public cabin: any;
  public classOfService: any;
}

export class ConnectionPointCondition {
  public comparator: string;
  public inSequence: boolean;
  public connectionCity: ConnectionCity[];
}

export class ConnectionCity {
  public airports: ConnectionCityAirport;
  public time: TimeConnectionCity;
}

export class ConnectionCityAirport {
  public arrival: any;
  public departure: any;
}

export class TimeConnectionCity {
  public maximumMinutes: number;
  public minimumMinutes: number;
}

export class ConnectionTimeCondition {
  public comparator: string;
  public connectionTime: ConnectionTime[];
}

export class ConnectionTime {
  public minutes: number;
  public city: any;
}

export class EquipmentCondition {
  public comparator: string;
  public configCode: any;
  public iataCode: any;
}

export class FlightCondition {
  public comparator: string;
  public flight: Flight[];
  public flightGrouping: any;
}

export class Flight {
  public startFlight: string;
  public endFlight: string;
}

export class FrequentFlyerCondition {
  public comparator: string;
  public frequentFlyer: FrequentFlyer[];
}

export class FrequentFlyer {
  public program: string;
  public tier: string;
}

export class LoadFactorCondition {
  public comparator: string;
  public startPercent: number;
  public endPercent: number;
  public cabin: any;
  public leg: LoadFactorLeg[];
}

export class LoadFactor {
  public percentComparator: string;
  public startPercent: number;
  public endPercent: number;
  public cabin: any;
  public leg: LoadFactorLeg[];
}

export class LoadFactorLeg {
  public origin: any;
  public destination: any;
}

export class MarketCondition {
  public comparator: string;
  public market: Market[];
  public segment: Segment[];
}

export class Segment {
  public origin: string;
  public destination: string;
}

export class Market {
  public marketGrouping: any;
  public market: MarketGrouping[];
}

export class MarketGrouping {
  public origin: string;
  public destination: string;
  public bidirectional: boolean;
}

export class PointOfCommencementCondition {
  public comparator: string;
  public city: string;
}

export class PointOfSaleCondition {
  public comparator: string;
  public businessId: any;
  public carrierOrGds: any;
  public communicationNumber: any;
  public country: any;
  public currency: any;
  public originatingSystem: any;
  public gdsOaCity: any;
  public geographicalCity: any;
  public iataNumber: any;
  public originatorsRequest: any;
  public posGrouping: any;
  public pseudoCity: any;
  public region: any;
  public userType: any;
}

export class RoutingCondition {
  public comparator: string;
  public routing: Routing;
}

export class Routing {
  public connectType: string;
  public direct: boolean;
  public nonStop: boolean;
  public domestic: boolean;
  public connectionCount: any;
  public carrier: string;
}

export class TimeDepartureCondition {
  public comparator: string;
  public time: Time;
}

export class Time {
  public days: number;
  public hours: number;
  public minutes: number;
}

export class RuleRs {
  public rsStandardPayload: RsStandardPayload;
  public rule: Rule[];
  public ruleSummary: RuleSummary[];
}

export class RuleSummary {
  public id: number;
  public name: string;
  public quickRule: string;
  public status: string;
  public time: string;
  public type: string;
  public userId: string;
  public version: number;
}
