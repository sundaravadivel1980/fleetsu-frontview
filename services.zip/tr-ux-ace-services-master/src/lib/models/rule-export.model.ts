import { RqStandardPayload } from './rule-rq-payload.model';
import { Rule } from './rules';

export class RuleExportRq {
    public rqStandardPayload: RqStandardPayload;
    public rule: Rule[];
}
