import { RsStandardPayload } from './rule-rs-payload.model';
import { Values } from './values';

export class CarrierPreference {
    public name: string;
    public description: string;
    public values: Values[];
}

export class CarrierPreferencesRs {
    public carrierPreference: CarrierPreference[];
    public rsStandardPayload: RsStandardPayload;
}
