export const ServiceConstants = {
    retryCount: 3
};
