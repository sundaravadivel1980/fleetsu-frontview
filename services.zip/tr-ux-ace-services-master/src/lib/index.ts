/**
 * App
 */
export * from './services';
export * from './models';

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HttpClientModule } from '@angular/common/http';

import { MarketGroupService } from './services/market-group/market-group.service';
import { RuleService } from './services/rule/rule.service';
import { AirportsService } from './services/shared/airports.service';
import { CityAirportService } from './services/shared/city-airports.service';
import { StartupService } from './services/shared/startup.service';

@NgModule({
    imports: [
      CommonModule,
      HttpClientModule
    ],
    declarations: [],
    exports: [
      HttpClientModule
    ],
    providers: [
      MarketGroupService,
      RuleService,
      AirportsService,
      CityAirportService,
      StartupService
    ]
  })

export class ServicesModule {}
