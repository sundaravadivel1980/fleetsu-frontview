import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AirportsService {
  private URL: string = '../../assets/jsons/airports.json';

  constructor(private http: HttpClient) { }

  public getAirportsJson(): Observable<any> {
    return this.http.get (this.URL);
  }
}
