import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { CityAirportRs } from '../../models/city-airport';
import 'rxjs/add/operator/retry';

@Injectable()
export class CityAirportService {

constructor(private httpClient: HttpClient) {}

 public getCityAirports(url: string): Observable < CityAirportRs > {
   return this.httpClient.get<any>(url).retry(3);
 }
}
