import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { AirlineRs } from '../../models/airline';
import { CarrierPreferencesRs } from '../../models/carrier-preferences';
import { TableStructureRs } from '../../models/table';
import { CountryRs } from '../../models/country';
import { CurrencyRs } from '../../models/currency';
import { GroupingRs } from '../../models/grouping';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/retry';

@Injectable()
export class StartupService {

constructor(private httpClient: HttpClient) {}

 public getCarriers(url: string): Observable < AirlineRs > {
   return this.httpClient.get<AirlineRs>(url).retry(3);
 }

 public getCarrierPreferences(url: string): Observable < CarrierPreferencesRs > {
  return this.httpClient.get<CarrierPreferencesRs>(url).retry(3);
 }

 public getCountries(url: string): Observable < CountryRs > {
  return this.httpClient.get<CountryRs>(url).retry(3);
 }

 public getCurrencies(url: string): Observable < CurrencyRs > {
  return this.httpClient.get<CurrencyRs>(url).retry(3);
 }

 public getReferenceTables(url: string): Observable < TableStructureRs > {
  return this.httpClient.get<TableStructureRs>(url).retry(3);
 }

 public getGroups(url: string): Observable < GroupingRs > {
  return this.httpClient.get<GroupingRs>(url).retry(3);
 }

}
