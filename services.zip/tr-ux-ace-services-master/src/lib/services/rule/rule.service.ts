import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { RuleRq, RuleRs } from '../../models/rules';
import { RuleExportRq } from '../../models/rule-export.model';
import { ServiceConstants } from '../../service.constants';
import 'rxjs/add/operator/retry';

@Injectable()
export class RuleService {

constructor(private httpClient: HttpClient) {}

 public getAllRules(url: string): Observable<RuleRs> {
   return this.httpClient.get<RuleRs>(url).retry(ServiceConstants.retryCount);
 }

 public getRules(url: string, status: string, type: string): Observable<RuleRs> {
  // let params = new HttpParams().set('status', status).set('ruleSet',type);
  let params: any;
  if (status === undefined || status === '' || status === 'null' ) {
        params = new HttpParams().set('ruleSet', type);
    } else if (type === undefined || type === '' || type === 'null' ) {
        params = new HttpParams().set('status', status);
    } else {
        params = new HttpParams().set('status', status).set('ruleSet', type);
    }
  return this.httpClient.get<RuleRs>(url, {params}).retry(ServiceConstants.retryCount);

 }

 public createRule(url: string, ruleData: RuleRq) {
    return this.httpClient.post(url, ruleData,
        {headers: new HttpHeaders().set('Content-Type', 'application/json')});
 }

 public getRule(url: string): Observable<RuleRs> {
    return this.httpClient.get<RuleRs>(url);
 }

 public updateRule(url: string, ruleData: RuleRq) {
    return this.httpClient.put(url, ruleData,
        {headers: new HttpHeaders().set('Content-Type', 'application/json')});
 }

 public deleteRule(url: string) {
    return this.httpClient.delete(url);
 }

 public exportRule(url: string, ruleData: RuleExportRq) {
  return this.httpClient.put(url, ruleData,
    {headers: new HttpHeaders().set('Content-Type', 'application/json'), responseType: 'blob' });
 }

}
