export class MarketGroup {
  constructor(public id: number, public name: string) { }
}
