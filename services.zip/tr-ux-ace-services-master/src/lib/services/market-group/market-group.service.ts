import { Injectable } from '@angular/core';
import { MarketGroup } from './market-group';

const MARKETGROUPS: MarketGroup[] = [
  new MarketGroup(1, 'Market Group1'),
  new MarketGroup(2, 'Market Group2'),
  new MarketGroup(3, 'Market Group3'),
  new MarketGroup(4, 'Market Group4'),
];

const FETCH_LATENCY = 500;

@Injectable()
export class MarketGroupService {

 public getMarketGroupes() {
    return null;
  }

  public getMarketGroup(id: number | string) {
    return null;
  }

}
