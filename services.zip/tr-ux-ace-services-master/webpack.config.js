
const helpers = require('./config/helpers');
const ngcWebpack = require('ngc-webpack');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const PurifyPlugin = require('@angular-devkit/build-optimizer').PurifyPlugin;
const ModuleConcatenationPlugin = require('webpack/lib/optimize/ModuleConcatenationPlugin');

const AngularCompilerPlugin = require('@ngtools/webpack').AngularCompilerPlugin;


module.exports = function (options) {

    const entry = {
      main: helpers.root('src', 'lib','index.ts')
    };  
  
	return {

	entry: entry,

	output: {
		path: helpers.root('dist','lib'),
		publicPath: '/',
		filename: 'index.js',
		//chunkFilename: '[name].[chunkhash].chunk.js',
		library: 'tr-ux-ace-services',
		libraryTarget: 'umd'
	},

	// require those dependencies but don't bundle them
	externals: [/^\@angular\//, /^rxjs\//],

	resolve: {
        
        /**
         * An array of extensions that should be used to resolve modules.
         *
         * See: http://webpack.github.io/docs/configuration.html#resolve-extensions
         */
        extensions: ['.ts', '.js', '.json'],
  
        /**
         * An array of directory names to be resolved to the current directory
         */
		modules: [helpers.root('src'), helpers.root('node_modules')]
    },    

	module: {
		rules: [
			
			{
				enforce: 'pre',
				test: /\.ts$/,
				loader: 'tslint-loader',
				exclude: [helpers.root('node_modules')]
			},


			{
                test: /(?:\.ngfactory\.js|\.ngstyle\.js|\.ts)$/,
                use: [ '@ngtools/webpack' ]
            },			
			
			
		]
	},

	plugins: [


        new PurifyPlugin(), /* buildOptimizer */
        
		new ModuleConcatenationPlugin(),
		
		/*new AngularCompilerPlugin({
			// true means AOT false. Currently we are packing as non AOT build since there is some issues in AOT build
			// The tr-ux-ace show error if core is built in AOT mode
			skipCodeGeneration:true, // true means AOT false
			tsConfigPath: helpers.root('tsconfig.webpack.json'),
			entryModule: __dirname + '/src/lib/index#ServicesModule',
			sourceMap: true
		}),*/


		new ngcWebpack.NgcWebpackPlugin({
			AOT: false,                            // alias for skipCodeGeneration: false
			tsConfigPath: helpers.root('tsconfig.webpack.json'),
			mainPath: 'src/lib/index.ts',               // will auto-detect the root NgModule.
			entryModule: __dirname + '/src/lib/index#ServicesModule'
		})
	],


    node: {
		global: true,
		crypto: 'empty',
		process: false,
		module: false,
		clearImmediate: false,
		setImmediate: false
	  }
  
	};
  }
  