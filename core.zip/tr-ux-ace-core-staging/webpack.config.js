
const helpers = require('./config/helpers');
const ngcWebpack = require('ngc-webpack');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const LoaderOptionsPlugin = require('webpack/lib/LoaderOptionsPlugin');
const SourceMapDevToolPlugin = require('webpack/lib/SourceMapDevToolPlugin');
const PurifyPlugin = require('@angular-devkit/build-optimizer').PurifyPlugin;
const ModuleConcatenationPlugin = require('webpack/lib/optimize/ModuleConcatenationPlugin');
const autoprefixer = require('autoprefixer');
const postcssUrl = require('postcss-url');
const ExtractTextPlugin = require('extract-text-webpack-plugin');

const AngularCompilerPlugin = require('@ngtools/webpack').AngularCompilerPlugin;

const baseHref = "";
const deployUrl = "";

const postcssPlugins = function () {
	return [
		postcssUrl({
			url: 'rebase'
		}),
		autoprefixer({
			browsers: ['last 2 versions', 'ie 11', '> 5%', 'Firefox > 35', 'Chrome > 35'],
			cascade: false
		}),
	];
};

let postCssLaoder = {
	loader: 'postcss-loader',
	options: {
		"plugins": postcssPlugins,
	}
};

module.exports = function (options) {

    const entry = {
      main: helpers.root('src', 'lib','index.ts')
    };  
  
	return {

	entry: entry,

	output: {
		path: helpers.root('dist','lib'),
		publicPath: '/',
		filename: 'index.js',
		//chunkFilename: '[name].[chunkhash].chunk.js',
		library: 'tr-ux-ace-core',
		libraryTarget: 'umd'
	},

	// require those dependencies but don't bundle them
	externals: [/^\@angular\//, /^rxjs\//],

	resolve: {
        
        /**
         * An array of extensions that should be used to resolve modules.
         *
         * See: http://webpack.github.io/docs/configuration.html#resolve-extensions
         */
        extensions: ['.ts', '.js', '.json'],
  
        /**
         * An array of directory names to be resolved to the current directory
         */
		modules: [helpers.root('src'), helpers.root('node_modules')]
    },    

	module: {
		rules: [
			
			{
				enforce: 'pre',
				test: /\.ts$/,
				loader: 'tslint-loader',
				exclude: [helpers.root('node_modules')]
			},

			// ...ngcWebpackConfig.loaders,

			{
                test: /(?:\.ngfactory\.js|\.ngstyle\.js|\.ts)$/,
                use: [ '@ngtools/webpack' ]
            },
			
			// copy those assets to output
			{
				test: /\.(svg|woff|woff2|ttf|eot)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
				loader: 'file-loader',
				options: {
					name: '[name].[ext]',
					outputPath: '../assets/fonts/',
					publicPath: ''
					// publicPath: '~@dxc/tr-ux-ace-core/'
				}
			},

			// copy those assets to output
			{
				test: /\.(png|jpe?g|jpg|gif|ico)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
				loader: 'url-loader',
				options: {
					limit: 1000000
				}
			},
			{
				test: /\.html$/,
				loader: 'raw-loader',
				query: {
					minimize: false
				}
			},

			
			/**
			 * To string and css loader support for *.css files (from Angular components)
			 * Returns file content as string
			 *
			 */
			{
				test: /\.css$/,
				use: [{
						loader: 'to-string-loader'
					},
					postCssLaoder,
					{
						loader: 'css-loader'
					}
				],
				exclude: [helpers.root('src', 'styles')]
			},

			/**
			 * To string and sass loader support for *.scss files (from Angular components)
			 * Returns compiled css content as string
			 *
			 */
			{
				test   : /\.scss$/,
				use: [
					{
						loader: 'to-string-loader'
					},
					{
					  loader: 'css-loader',
					  options: {
						sourceMap: true
					  }
					}, {
					  loader: 'resolve-url-loader'
					}, {
					  loader: 'sass-loader',
					  options: {
						sourceMap: true
					  }
					}
				  ],
				exclude: [helpers.root('src', 'styles')]
			},

			/**
			 * Extract CSS files from .src/styles directory to external CSS file
			 */
			{
				test: /\.css$/,
				loader: ExtractTextPlugin.extract({
					fallback: 'style-loader',
					use: [{
							loader: 'css-loader'
						},
						postCssLaoder
					]
				}),
				include: [helpers.root('src', 'styles')]
			},

			/**
			 * Extract and compile SCSS files from .src/styles directory to external CSS file
			 */
			{
				test: /\.scss$/,
				loader: ExtractTextPlugin.extract({
					fallback: 'style-loader',
					use: [
						{
							loader: 'css-loader'
						},
						postCssLaoder,
						{
							loader: 'sass-loader'
						}
					]
				}),
				include: [helpers.root('src', 'styles')]
			},
			
			
		]
	},

	plugins: [

		
        new SourceMapDevToolPlugin({
            filename: '[file].map[query]',
            moduleFilenameTemplate: '[resource-path]',
            fallbackModuleFilenameTemplate: '[resource-path]?[hash]',
            sourceRoot: 'webpack:///'
        }),

        new PurifyPlugin(), /* buildOptimizer */
        
		new ModuleConcatenationPlugin(),
		
		/*new AngularCompilerPlugin({
			// true means AOT false. Currently we are packing as non AOT build since there is some issues in AOT build
			// The tr-ux-ace show error if core is built in AOT mode
			skipCodeGeneration:true, // true means AOT false
			tsConfigPath: helpers.root('tsconfig.webpack.json'),
			entryModule: __dirname + '/src/lib/index#DxcCoreModule',
			sourceMap: true
		}),*/


		new ngcWebpack.NgcWebpackPlugin({
			AOT: false,                            // alias for skipCodeGeneration: false
			tsConfigPath: helpers.root('tsconfig.webpack.json'),
			mainPath: 'src/lib/index.ts',               // will auto-detect the root NgModule.
			entryModule: __dirname + '/src/lib/index#DxcCoreModule'
		}), 		
  

		// Copy the html and css files manually to support AOT build of project accessing tr-ux-ace-core
		new CopyWebpackPlugin([
			{ from: 'src/lib', to: '../lib', ignore: ['**/*.ts', '**/*.spec.ts','package.json']},
			{ from: 'src/styles', to: '../styles'},
			{ from: 'src/assets', to: '../assets'}
		]),

		/** extracts embedded css as external files, adding cache-busting hash to the filename. */
		new ExtractTextPlugin('tr-ux-ace-core.css')
	],


    node: {
		global: true,
		crypto: 'empty',
		process: false,
		module: false,
		clearImmediate: false,
		setImmediate: false
	  }
  
	};
  }
  