import { NgModule } from '@angular/core';
import {
    MatFormFieldModule,
    MatCheckboxModule,
    MatAutocompleteModule,
    MatSlideToggleModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatSortModule,
    MatDatepickerModule,
    MatChipsModule,
    MatRadioModule,
    MatNativeDateModule,
    MatButtonToggleModule,
    MatMenuModule,
    MatSidenavModule,
    MatToolbarModule,
    MatExpansionModule,
    MatDialogModule,
    MatTableModule,
    MatCardModule,
    MatPaginatorModule,
    MatGridListModule,
    MatListModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRippleModule,
    MatSliderModule,
    MatSnackBarModule,
    MatStepperModule,
    MatTabsModule,
    MatTooltipModule,
    ErrorStateMatcher,
    ShowOnDirtyErrorStateMatcher
} from '@angular/material';
import { A11yModule } from '@angular/cdk/a11y';
import { BidiModule } from '@angular/cdk/bidi';
import { ScrollDispatchModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import { FlexLayoutModule } from '@angular/flex-layout';
import { PortalModule } from '@angular/cdk/portal';
import { PlatformModule } from '@angular/cdk/platform';
import { ObserversModule } from '@angular/cdk/observers';
import { OverlayModule } from '@angular/cdk/overlay';
import { OverlayContainer } from '@angular/cdk/overlay';
import { AceOverlayContainer } from './index';

export function overlayFactory() {
    return new AceOverlayContainer(document);
}

@NgModule({
    imports: [
        A11yModule,
        BidiModule,
        ScrollDispatchModule,
        CdkStepperModule,
        CdkTableModule,
        MatFormFieldModule,
        MatCheckboxModule,
        MatAutocompleteModule,
        MatSlideToggleModule,
        MatButtonModule,
        MatIconModule,
        MatInputModule,
        MatSelectModule,
        MatSortModule,
        MatDatepickerModule,
        MatChipsModule,
        MatRadioModule,
        MatNativeDateModule,
        MatButtonToggleModule,
        MatExpansionModule,
        MatDialogModule,
        MatTableModule,
        MatMenuModule,
        MatSidenavModule,
        MatToolbarModule,
        MatCardModule,
        MatPaginatorModule,
        MatTooltipModule,
        MatGridListModule,
        MatListModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatRippleModule,
        MatSliderModule,
        MatSnackBarModule,
        MatStepperModule,
        MatTabsModule,
        FlexLayoutModule,
        ObserversModule,
        OverlayModule,
        PlatformModule,
        PortalModule,
    ],
    exports: [
        A11yModule,
        BidiModule,
        ScrollDispatchModule,
        CdkStepperModule,
        CdkTableModule,
        MatFormFieldModule,
        MatCheckboxModule,
        MatAutocompleteModule,
        MatSlideToggleModule,
        MatButtonModule,
        MatIconModule,
        MatInputModule,
        MatSelectModule,
        MatSortModule,
        MatDatepickerModule,
        MatChipsModule,
        MatRadioModule,
        MatNativeDateModule,
        MatButtonToggleModule,
        MatExpansionModule,
        MatDialogModule,
        MatTableModule,
        MatMenuModule,
        MatSidenavModule,
        MatToolbarModule,
        MatCardModule,
        MatPaginatorModule,
        MatTooltipModule,
        MatGridListModule,
        MatListModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatRippleModule,
        MatSliderModule,
        MatSnackBarModule,
        MatStepperModule,
        MatTabsModule,
        FlexLayoutModule,
        ObserversModule,
        OverlayModule,
        PlatformModule,
        PortalModule,
    ],
    providers: [
        { provide: OverlayContainer, useFactory: overlayFactory },
        { provide: ErrorStateMatcher, useClass: ShowOnDirtyErrorStateMatcher }
    ]
})
export class MaterialModule { }

