export * from './models/dxc-nav-item.interface';
export * from './services/user';
export * from './services/message';
export * from './services/message.service';
export * from './services/dialog.service';
export * from './services/ace-overlay-container';
export * from './components/dxc-alert-message/dxc-alert-message.component';
export * from './components/dxc-confirm-dialog/dxc-confirm-dialog.component';
export * from './components/dxc-app-layout/dxc-app-layout.component';
export * from './components/dxc-header/dxc-header.component';
export * from './components/dxc-session/dxc-session.component';
export * from './components/dxc-navigation/dxc-navigation.component';
export * from './components/dxc-class-selector/dxc-class-selector.component';
export * from './material.module';
export * from './angular.module';

import { NgModule, ModuleWithProviders } from '@angular/core';

import { MessageService } from './services/message.service';
import { DialogsService } from './services/dialog.service';
import { MaterialModule } from './material.module';
import { AngularModule } from './angular.module';

import { DxcHeaderComponent } from './components/dxc-header/dxc-header.component';
import {  DxcAppLayoutComponent,
          DxcAppRightContentComponent,
          DxcAppLeftContentComponent,
          DxcAppCenterContentComponent,
          DxcAppTopContentComponent
        } from './components/dxc-app-layout/dxc-app-layout.component';
import { DxcSessionComponent,
         DxcSessionControlsComponent,
         DxcSessionContentComponent
       } from './components/dxc-session/dxc-session.component';
import { DxcNavigationComponent } from './components/dxc-navigation/dxc-navigation.component';
import { DxcClassSelectorComponent } from './components/dxc-class-selector/dxc-class-selector.component';
import { DxcAlertMessageComponent } from './components/dxc-alert-message/dxc-alert-message.component';
import { DxcChipsComponent } from './components/custom-fields/dxc-chips/dxc-chips.component';
import { DxcChipAutocompleteComponent } from './components/custom-fields/dxc-chip-autocomplete/dxc-chip-autocomplete.component';
import { DxcConfirmDialogComponent } from './components/dxc-confirm-dialog/dxc-confirm-dialog.component';
import { ValidationFormatterDirective } from './directives/validation-formatter.directive';

import '../styles/styles.scss';

@NgModule({
  imports: [
    AngularModule,
    MaterialModule,
  ],
  declarations: [
    DxcAlertMessageComponent,
    DxcAppLayoutComponent,
    DxcAppLeftContentComponent,
    DxcAppRightContentComponent,
    DxcAppCenterContentComponent,
    DxcAppTopContentComponent,
    DxcHeaderComponent,
    DxcSessionComponent,
    DxcSessionControlsComponent,
    DxcSessionContentComponent,
    DxcNavigationComponent,
    DxcClassSelectorComponent,
    DxcChipsComponent,
    DxcChipAutocompleteComponent,
    DxcConfirmDialogComponent,
    ValidationFormatterDirective
  ],
  exports: [
    AngularModule,
    MaterialModule,
    DxcAlertMessageComponent,
    DxcAppLayoutComponent,
    DxcAppLeftContentComponent,
    DxcAppRightContentComponent,
    DxcAppCenterContentComponent,
    DxcAppTopContentComponent,
    DxcHeaderComponent,
    DxcSessionComponent,
    DxcSessionControlsComponent,
    DxcSessionContentComponent,
    DxcNavigationComponent,
    DxcClassSelectorComponent,
    DxcChipsComponent,
    DxcChipAutocompleteComponent,
    DxcConfirmDialogComponent,
    ValidationFormatterDirective
  ],
  providers: [],
  entryComponents: [
    DxcConfirmDialogComponent
  ]
})
export class DxcCoreModule { }
