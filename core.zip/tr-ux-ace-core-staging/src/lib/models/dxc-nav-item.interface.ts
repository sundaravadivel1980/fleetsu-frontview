export interface DxcNav {
    Name:string;
    Link?:string;
}