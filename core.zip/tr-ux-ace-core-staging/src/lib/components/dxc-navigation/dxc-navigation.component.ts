import { Component, OnInit, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { DxcNav } from '../../models/dxc-nav-item.interface';

@Component({
  selector: 'dxc-nav',
  templateUrl: './dxc-navigation.component.html',
  styleUrls: ['./dxc-navigation.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DxcNavigationComponent implements OnInit {
  @Input('nav-items')
  public navItems: DxcNav[] = [];

  @Input('active-item')
  public activeItem: number = 0;

  @Output('itemclick')
  onItemClick = new EventEmitter();

  constructor() {
    // to-do
  }

  public ngOnInit() {
    // to-do
  }

  public changeActiveItem(index: number) {
    this.activeItem = index;
    this.onItemClick.emit({value:index});
  }

}