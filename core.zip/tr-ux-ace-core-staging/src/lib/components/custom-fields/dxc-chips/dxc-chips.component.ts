import { Component, OnInit, forwardRef, Input, Output, OnChanges,
    AfterViewInit, EventEmitter } from '@angular/core';
import { FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { CustomFieldsAbstractClass } from '../custom-fields-abstract-class';
import { MatChipInputEvent } from '@angular/material';
import { Placeholder } from '@angular/compiler/src/i18n/i18n_ast';

const COMMA = 188;
const ENTER = 13;

@Component({
    selector: 'dxc-chips',
    templateUrl: 'dxc-chips.component.html',
    styleUrls: ['dxc-chips.component.scss']
})
export class DxcChipsComponent implements OnInit {
    public visible: boolean = true;
    public selectable: boolean = true;
    public removable: boolean = true;
    public addOnBlur: boolean = true;
    @Input() public forEdit: any;
    @Input() public placeholder: string;
    @Input() public inputValidationFormat: string;
    @Output() public forSave = new EventEmitter();
    @Input() public maxChipsAllow: number = this.maxChipsAllow ? this.maxChipsAllow : 4;

    public separatorKeysCodes = [ENTER, COMMA];
    public selectedChips = [];

    public ngOnInit() {
        this.ForEditControl(this.forEdit);
        this.placeholder = this.placeholder || '';
        this.inputValidationFormat = this.inputValidationFormat || '';
    }

    public add(event: MatChipInputEvent): void {
        const input = event.input;
        const value = event.value;
        if ((value || '').trim()) {
            this.selectedChips.push(value.trim());
        }
        if (input) {
            input.value = '';
        }
        this.forSave.emit(this.selectedChips);
    }

    public remove(chip: any): void {
        const index = this.selectedChips.indexOf(chip);
        if (index >= 0) {
            this.selectedChips.splice(index, 1);
        }
        this.forSave.emit(this.selectedChips);
    }

    public ForEditControl(value) {
        if ((value && value !== null && value.length >= 1) &&
            (this.selectedChips === undefined || this.selectedChips.length < 1)) {
            this.selectedChips = value;
        }
    }

}
