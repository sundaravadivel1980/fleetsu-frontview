import {
  Component, EventEmitter, Output, Input, OnInit, AfterViewInit, OnChanges,
  ViewEncapsulation, ElementRef
} from '@angular/core';
import { FormControl } from '@angular/forms';
import {
  MatAutocompleteSelectedEvent,
  MatChipInputEvent,
  MatAutocompleteTrigger
} from '@angular/material';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'dxc-chip-autocomplete',
  templateUrl: 'dxc-chip-autocomplete.component.html',
  styleUrls: ['dxc-chip-autocomplete.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class DxcChipAutocompleteComponent implements OnInit, AfterViewInit, OnChanges {
  @Output() public selectedList: any = new EventEmitter();
  @Input() public dropdownList: any;      // required
  @Input() public dropdownLimit: number;  // optional
  @Input() public searchLimit: number;    // optional
  @Input() public isOD: boolean;    // optional
  @Input() public forEdit: any;
  @Input() public placeholder: string;
  @Input() public displayDropdownByDefault: boolean;
  @Input() public maxChipsAllow: number = this.maxChipsAllow ? this.maxChipsAllow : 4;
  @Input() public hint: string;
  @Input() public errorDisplay: boolean = false;
  @Input() public errorMessage: string;
  @Input() public replaceStop: string = this.replaceStop ? this.replaceStop : '***';

  public autoCompleteChipList: FormControl = new FormControl();
  public visible: boolean = true;
  public selectable: boolean = true;
  public removable: boolean = true;
  public addOnBlur: boolean = true;
  public dropdownValue: any;
  public hideInput: string = 'block';
  public isHidden: boolean = false;
  public highlighterror: boolean = false;
  public tempHint: string;

  public filteredOptions: Observable<any[]>;
  public chips: any = [];

  public constructor(private elRef: ElementRef) {
    // console
  }

  public ngOnInit() {
    this.tempHint = this.hint;
    this.dropdownValue = this.dropdownList;
    if (this.displayDropdownByDefault && this.displayDropdownByDefault === true) {
      this.filteredOptions = this.dropdownValue.slice(0, 10);
    }
    this.autoCompleteChipList.valueChanges.debounceTime(300).subscribe(
      (val) => {
        this.hideInput = this.chips.length >= this.maxChipsAllow ? 'none' : 'block';
        this.updateDropdown(val);
      }
    );
    this.isHidden = this.chips.length >= this.maxChipsAllow;
    this.ForEditControl(this.forEdit);
  }

  public ngOnChanges() {
    if (this.errorDisplay) {
      this.highlighterror = true;
      this.tempHint = this.errorMessage;
    }
    if (this.chips.length > 0) {
      this.highlighterror = false;
      this.tempHint = this.hint;
    }
  }

  public ngAfterViewInit() {
    // this.inputElement = this.elRef.nativeElement.querySelector('.autoInput');
  }

  public updateDropdown(str: string) {
    const strLength = str.length;
    const searchLimit = this.searchLimit ? this.searchLimit : 1;
    const dropLimit = this.dropdownLimit ? this.dropdownLimit : 10;
    const selectedChipLength = this.chips.length;

    if (this.maxChipsAllow <= selectedChipLength) {
      this.filteredOptions = this.dropdownValue.slice(0, 0);
    } else if (strLength >= searchLimit) {
      this.filteredOptions = this.dropdownValue
        .filter(
          (e) => {
            return (e.id.toLowerCase().indexOf(str.toString().toLowerCase()) === 0) ||
              (e.value.toLowerCase().indexOf(str.toString().toLowerCase()) !== -1);
          }
        )
        .sort(
          (a, b) => {
            return (a.id.toLowerCase().indexOf(str.toLowerCase()) === 0) ? -1 :
              (b.id.toLowerCase().indexOf(str.toLowerCase()) === 0) ? 1 : 0;
          }
        )
        .slice(0, dropLimit);
    } else if (this.displayDropdownByDefault === true && strLength === 0) {
      this.filteredOptions = this.dropdownValue.slice(0, 10);
    } else {
      this.filteredOptions = this.dropdownValue.slice(0, 0);
    }
  }

  public addChip(event: MatAutocompleteSelectedEvent, input: any): void {
    const selection = event.option.value;
    if (selection.id === this.replaceStop) {
      this.chips = [];
      this.isHidden = true;
    }
    this.chips.push(selection);
    this.dropdownValue = this.dropdownValue.filter((obj) => obj.id !== selection.id);
    if (input) {
      input.value = '';
    }
    this.returnData(this.chips);
    if (this.displayDropdownByDefault === true) {
      this.filteredOptions = this.dropdownValue.slice(0, 10);
    }
  }

  public removeChip(chip: any): void {
    const index = this.chips.indexOf(chip);
    if (chip.id === this.replaceStop) {
      this.isHidden = this.chips.length >= this.maxChipsAllow;
    }
    if (index >= 0) {
      this.chips.splice(index, 1);
      this.dropdownValue.push(chip);
    }
    this.returnData(this.chips);
    if (this.displayDropdownByDefault === true) {
      this.filteredOptions = this.dropdownValue.slice(0, 10);
    }
  }

  public returnData(value) {
    const selectedChips = [];
    for (const chip of value) {
      selectedChips.push(chip.id);
    }
    this.selectedList.emit(selectedChips);
  }

  public ForEditControl(value) {
    if ((value && value !== null && value.length >= 1) &&
      (this.chips === undefined || this.chips.length < 1)) {
      for (const item of value) {
        const valChip = this.dropdownValue.filter((obj) => obj.id === item);
        this.chips.push(valChip[0]);
        this.dropdownValue = this.dropdownValue.filter((obj) => obj.id !== item);
        if (item === this.replaceStop) {
          this.isHidden = true;
        }
      }
    }
  }
}
