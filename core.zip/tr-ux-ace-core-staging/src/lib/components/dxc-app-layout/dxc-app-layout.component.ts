import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';

@Component({
  selector: 'dxc-app-layout',
  templateUrl: './dxc-app-layout.component.html',
  styleUrls: ['./dxc-app-layout.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DxcAppLayoutComponent implements OnInit {
  @Input() scrollable:boolean = true;
  constructor() {
    // to-do
  }

  public ngOnInit() {
    // to-do
  }

}


@Component({
  selector: 'dxc-app-top-content',
  template: `<ng-content></ng-content>`,
  host:{
    '[style.height]':'height'
  },
  encapsulation: ViewEncapsulation.None
})
export class DxcAppTopContentComponent implements OnInit {
  @Input() height: string = "50px";
  constructor() {
    // to-do
  }

  public ngOnInit() {
    // to-do
  }

}


@Component({
  selector: 'dxc-app-left-content',
  template: `<ng-content></ng-content>`,
  host:{
    '[style.min-width]':'width',
    '[style.max-width]':'width',
  },
  encapsulation: ViewEncapsulation.None
})
export class DxcAppLeftContentComponent implements OnInit {
  @Input() width: string = "200px";
  constructor() {
    // to-do
  }

  public ngOnInit() {
    // to-do
  }

}

@Component({
  selector: 'dxc-app-right-content',
  template: `<ng-content></ng-content>`,
  host:{
    '[style.min-width]':'width',
    '[style.max-width]':'width',
  },
  encapsulation: ViewEncapsulation.None
})
export class DxcAppRightContentComponent implements OnInit {
  @Input() width: string = "200px";
  constructor() {
    // to-do
  }

  public ngOnInit() {
    // to-do
  }

}


@Component({
  selector: 'dxc-app-center-content',
  template: `
  <ng-content></ng-content>`,

  encapsulation: ViewEncapsulation.None
})
export class DxcAppCenterContentComponent implements OnInit {
  
  constructor() {
    // to-do
  }

  public ngOnInit() {
    // to-do
  }

}


