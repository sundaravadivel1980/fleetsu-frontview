import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';

@Component({
  selector: 'dxc-header',
  templateUrl: './dxc-header.component.html',
  styleUrls: ['./dxc-header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DxcHeaderComponent implements OnInit {
  @Input() public title: string = 'Application Title';
  constructor() {
    // to-do
  }

  public ngOnInit() {
    // to-do
  }

}


