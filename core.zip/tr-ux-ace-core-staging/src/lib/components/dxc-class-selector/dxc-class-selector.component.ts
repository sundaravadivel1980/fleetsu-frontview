import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'dxc-class-selector',
  templateUrl: './dxc-class-selector.component.html',
  styleUrls: ['./dxc-class-selector.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DxcClassSelectorComponent implements OnInit {
  constructor() { 
    // to-do
  }

  public ngOnInit() {
    // to-do
  }

}
