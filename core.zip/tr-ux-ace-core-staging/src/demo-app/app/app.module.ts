import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import {
  NgModule,
  ApplicationRef
} from '@angular/core';

import { RouterModule, PreloadAllModules } from '@angular/router';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ENV_PROVIDERS } from './environment';
import { ROUTES } from './app.routes';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { DxcCoreModule, AceOverlayContainer } from '../../lib';

import '../../styles/styles.scss';
import { OverlayContainer } from '@angular/cdk/overlay';
import { MessageService, DialogsService } from '../../lib/services';

@NgModule({
  bootstrap: [ AppComponent ],
  declarations: [
    AppComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpModule,
    DxcCoreModule,
    RouterModule.forRoot(ROUTES, {
      useHash: Boolean(history.pushState) === false,
      preloadingStrategy: PreloadAllModules
    })
  ],
  providers: [
    ENV_PROVIDERS,
    MessageService,
    DialogsService
  ]
})
export class AppModule {

  constructor(
    public appRef: ApplicationRef,
  ) {}
}
