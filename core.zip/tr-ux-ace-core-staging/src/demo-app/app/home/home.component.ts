import { Component, OnInit } from '@angular/core';

import { DxcNav, MessageService, DialogsService } from '../../../lib';
import { Router } from '@angular/router';

@Component({
    selector: 'home',
    templateUrl: './home.component.html'
})
export class HomeComponent implements OnInit {

    public navItems: DxcNav[] = [
        { Name: 'Home', Link: '.' },
        { Name: 'Directory', Link: '/about' },
        { Name: 'Test GUI', Link: '.' },
        { Name: 'Groups', Link: '.' }
    ];
    isVertical = false;
    isDisabled = false;
    favoritePie: string[] = ['A'];
    pieOptions = ['A', 'D', 'C', 'D', 'EF', 'GH'];
    constructor(private router: Router, private messageService:MessageService, private dialogService: DialogsService) { }

    public ngOnInit() {
        console.log('hello `Home` component');
        this.messageService.error("Bad Request. Unable to retrive valid response from server",true);
        this.messageService.warn("The data retrived may be incomplete",true);
        this.messageService.success("The rule has been activated",true);
        this.messageService.info("The rule has been activated",true);
        
    }

    public navigate(args) {
        console.log(args);
        if (args.value === 1) {
            this.router.navigate(["/about"]);
        }
    }

    public openDialog(){
        this.dialogService.confirm("Confirm Dialog", "Helloo!! This is a confirm message");
    }

}
